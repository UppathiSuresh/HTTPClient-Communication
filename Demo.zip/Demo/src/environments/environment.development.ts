export const environment = {
    apiURL:'https://localhost:7171'
};
